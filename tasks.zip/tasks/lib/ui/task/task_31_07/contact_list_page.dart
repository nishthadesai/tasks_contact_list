import 'package:auto_route/annotations.dart';
import 'package:flutter/material.dart';
import 'package:flutter_demo_structure/values/export.dart';
import 'package:flutter_demo_structure/values/extensions/widget_ext.dart';
import 'package:flutter_demo_structure/widget/base_app_bar.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../../data/my_data/contact_data.dart';
import '../../../generated/assets.dart';
import '../../../generated/l10n.dart';
import '../../../router/app_router.dart';
import '../../../widget/app_image.dart';
import '../../../widget/app_text_filed.dart';

@RoutePage()
class ContactListPage extends StatefulWidget {
  const ContactListPage({super.key});

  @override
  State<ContactListPage> createState() => _ContactListPageState();
}

class _ContactListPageState extends State<ContactListPage> {
  TextEditingController searchController = TextEditingController();
  List searchedContactList = [];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColor.white,
      appBar: buildAppBar(),
      body: buildView(),
    );
  }

  buildAppBar() {
    return BaseAppBar(
      backgroundColor: AppColor.white,
      showTitle: true,
      centerTitle: false,
      titleWidget: Text(
        S.of(context).list,
        style: textRegular.copyWith(
            fontSize: 16.spMin, color: Colors.indigoAccent),
      ),
      action: [
        GestureDetector(
          onTap: () {
            appRouter.push(AddContactRoute(contactData: null));
          },
          child: Icon(
            Icons.add,
            color: Colors.indigoAccent,
            size: 20,
          ).wrapPaddingRight(10),
        )
      ],
    );
  }

  Widget buildView() {
    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            S.of(context).contacts,
            style: textBold.copyWith(fontSize: 26.spMin, color: AppColor.black),
          ),
          15.verticalSpace,
          buildSearchBar(),
          20.verticalSpace,
          buildContactList(),
        ],
      ).wrapPaddingHorizontal(15),
    );
  }

  /**
   * This is search bar for contacts search...

   */
  Widget buildSearchBar() {
    return SizedBox(
      height: 30,
      child: AppTextField(
        onChanged: (val) {
          if (val != null) {
            setState(() {
              searchedContactList = contactDataList.value.where((contact) {
                String name =
                    "${contact.firstName.toLowerCase()} ${contact.lastName.toLowerCase()}";
                return name.contains(val.toLowerCase());
              }).toList();
            });
          }
        },
        decoration: InputDecoration(
          prefixIcon: Icon(
            Icons.search,
            size: 20.r,
            color: AppColor.grey,
          ),
          suffixIcon: Icon(
            Icons.mic,
            size: 20.r,
            color: AppColor.grey,
          ),
          hintText: "Search",
          hintStyle: textRegular.copyWith(
              fontSize: 16.spMin, color: AppColor.black.withOpacity(0.50)),
          contentPadding: EdgeInsets.zero,
          border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10).r,
              borderSide: BorderSide.none),
          filled: true,
          fillColor: AppColor.grey.withOpacity(0.10),
        ),
        keyboardType: TextInputType.name,
        keyboardAction: TextInputAction.search,
        textCapitalization: TextCapitalization.none,
        controller: searchController,
        label: '',
        hint: '',
      ),
    );
  }

  Widget buildContactList() {
    return searchController.text != ""
        ? searchedContactList.isEmpty
            ? Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Center(
                    child: Image.asset(
                      Assets.imageNoDataFound,
                      height: 100.r,
                      width: 100.w,
                    ),
                  ),
                  Text(
                    S.of(context).noContactsFound,
                    style: textMedium.copyWith(
                      fontSize: 16.spMin,
                      color: AppColor.black,
                    ),
                  ),
                ],
              )
            : Column(
                children: List.generate(
                  searchedContactList.length,
                  (index) {
                    ContactData contactData = searchedContactList[index];
                    return ListTile(
                      hoverColor: AppColor.transparent,
                      splashColor: AppColor.transparent,
                      contentPadding: EdgeInsets.zero,
                      minTileHeight: 40,
                      title: Text(
                        "${contactData.firstName.toTitleCase()} ${contactData.lastName.toTitleCase()}",
                        style: textMedium.copyWith(
                          fontSize: 14.spMin,
                          color: AppColor.black,
                        ),
                      ),
                      leading: AppImage(
                        radius: 16.r,
                        file: contactData.Image,
                      ),
                      subtitle: Text(
                        "${contactData.number}",
                        style: textMedium.copyWith(
                          fontSize: 12.spMin,
                          color: AppColor.black.withOpacity(0.80),
                        ),
                      ).wrapPaddingTop(5),
                    ).wrapPaddingBottom(5);
                  },
                ),
              )
        : ValueListenableBuilder(
            valueListenable: contactDataList,
            builder: (context, value, child) {
              final groupSortedContacts = sortAndGroupContacts();
              List<Widget> contactWidgets = [];
              groupSortedContacts.forEach((letter, contacts) {
                contactWidgets.add(
                  Text(
                    letter,
                    style: textMedium.copyWith(
                      fontSize: 16.spMin,
                      color: AppColor.black,
                    ),
                  ),
                );

                contactWidgets.add(Divider());

                for (var contact in contacts) {
                  contactWidgets.add(
                    Column(
                      children: [
                        GestureDetector(
                          onTap: () {
                            appRouter.push(
                              AddContactRoute(
                                  contactData: contact,
                                  index: value.indexOf(contact)),
                            );
                          },
                          child: ListTile(
                            hoverColor: AppColor.transparent,
                            splashColor: AppColor.transparent,
                            contentPadding: EdgeInsets.zero,
                            minTileHeight: 40,
                            title: Text(
                              "${contact.firstName.toTitleCase()} ${contact.lastName.toTitleCase()}",
                              style: textMedium.copyWith(
                                fontSize: 14.spMin,
                                color: AppColor.black,
                              ),
                            ),
                            leading: AppImage(
                              radius: 16.r,
                              file: contact.Image,
                            ),
                            subtitle: Text(
                              "${contact.number}",
                              style: textMedium.copyWith(
                                fontSize: 12.spMin,
                                color: AppColor.black.withOpacity(0.80),
                              ),
                            ).wrapPaddingTop(5),
                            trailing: Checkbox(
                              activeColor: Colors.indigoAccent,
                              shape: CircleBorder(eccentricity: 0.1.r),
                              onChanged: (value) {},
                              value: false,
                            ),
                          ),
                        ),
                        Divider(),
                      ],
                    ),
                  );
                }
              });

              return contactWidgets.isNotEmpty
                  ? Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: contactWidgets,
                    )
                  : Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Center(
                          child: Text(
                            S.of(context).noContactsYet,
                            style: textMedium.copyWith(
                              fontSize: 16.spMin,
                              color: AppColor.black,
                            ),
                          ),
                        ),
                      ],
                    );
            },
          );
  }

  Map<String, List<ContactData>> sortAndGroupContacts() {
    contactDataList.value.sort((a, b) => a.firstName.compareTo(b.firstName));

    Map<String, List<ContactData>> groupedContacts = {};
    for (var contact in contactDataList.value) {
      String firstLetter = contact.firstName[0].toUpperCase();
      if (groupedContacts[firstLetter] == null) {
        groupedContacts[firstLetter] = [];
      }
      groupedContacts[firstLetter]!.add(contact);
    }

    return groupedContacts;
  }

  @override
  void dispose() {
    searchController.dispose();
    super.dispose();
  }
}
